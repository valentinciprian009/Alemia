#pragma once
#include "Plant.h"
class Snow_pea :public Plant
{
public:
	Snow_pea();
	virtual~Snow_pea();
};

