#pragma once
#include "Plant.h"
class Peashooter:public Plant
{
public:
	Peashooter();
	virtual~Peashooter();
};