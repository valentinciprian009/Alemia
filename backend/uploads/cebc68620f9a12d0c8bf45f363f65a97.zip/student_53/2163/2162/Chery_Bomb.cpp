#include "Chery_Bomb.h"



Chery_Bomb::Chery_Bomb():Plant('C', 1000000,{10,32},150)
{
}




Chery_Bomb::~Chery_Bomb()
{
}
