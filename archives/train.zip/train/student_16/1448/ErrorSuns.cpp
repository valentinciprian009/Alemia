#include "ErrorSuns.h"



ErrorSuns::ErrorSuns()
{
}


ErrorSuns::~ErrorSuns()
{
}
