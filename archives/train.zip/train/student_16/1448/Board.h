#pragma once
class Board
{
private:
	const int nr_benzi;
public:
	
	Board(int nr_benzi);
	~Board();
};

