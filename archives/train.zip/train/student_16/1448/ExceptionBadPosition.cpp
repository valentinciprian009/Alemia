#include "ExceptionBadPosition.h"



ExceptionBadPosition::ExceptionBadPosition()
{
}


ExceptionBadPosition::~ExceptionBadPosition()
{
}
