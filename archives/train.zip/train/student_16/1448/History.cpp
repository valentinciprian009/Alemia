#include "History.h"



History::History()
{
}


History::~History()
{
}
