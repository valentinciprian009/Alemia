#include "Board.h"





Board::Board(int nr_benzi) : nr_benzi(nr_benzi)
{
	
}


Board::~Board()
{
}
