#include "DefeatMenuParser.h"

void DefeatMenuParser::parseAction(std::string action)
{
}
