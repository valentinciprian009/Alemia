#pragma once
class IComputerAction
{
public:
	virtual void doAction() = 0;
};

