#include "VictoryMenuParser.h"

void VictoryMenuParser::parseAction(std::string action)
{
}
