#include "GenericZombie.h"

GenericZombie::GenericZombie(int viata, int viteza)
{
	this->viata = viata;
	this->viteza = viteza;
}
