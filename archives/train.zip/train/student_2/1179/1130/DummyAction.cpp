#include "DummyAction.h"

void DummyAction::doAction()
{
	return;
}
