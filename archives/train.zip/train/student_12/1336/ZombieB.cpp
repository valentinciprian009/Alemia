#include "ZombieB.h"



ZombieB::~ZombieB()
{
}
