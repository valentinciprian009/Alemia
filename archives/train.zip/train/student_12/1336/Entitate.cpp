#include "Entitate.h"



Entitate::Entitate()
{
}


Entitate::~Entitate()
{
}
