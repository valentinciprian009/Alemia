#pragma once
#include "Zombie.h"
class ZombieB :
	public Zombie
{
public:
	ZombieB() :Zombie(x, y) {};
	~ZombieB();
};

