#include "Plant.h"



Plant::Plant()
{
}


Plant::~Plant()
{
}
