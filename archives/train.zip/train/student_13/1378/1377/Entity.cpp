#include "Entity.h"



Entity::Entity()
{
}


Entity::~Entity()
{
}
