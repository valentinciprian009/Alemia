#include "Zombies.h"



Zombies::Zombies()
{
}


Zombies::~Zombies()
{
}
