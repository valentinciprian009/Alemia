Sistemul de log in salveaza datele utilizatorilor noi intr-un fisier text
iar in cazul in care utilizatorii deja inregistrati se logheaza cu datele
corecte jocul proneste dupa Loading Screen.

Jucatorul poate colecta sorii care se genereaza random in locul casutelor
marcate cu litera 'O'.Zombii apar random pe fiecare linie,iar jucatorul are 
optiunea de a planta Pea sau Sunflower.

Jocul se termina cand Zombie ajung la player sau cand playerul reuseste sa
omoare toti zombii.