#pragma once
#include "Point.h"
//pastrez acest fisier amintire pentru prima versiune de doGraphics
namespace cnt1 {
	Point c1(0,0);
	Point c2(14,0);
	Point c3(0,4);
	Point c4(14, 4);
}


namespace cnt2 {
	Point c1(15,0);
	Point c2(150,0);
	Point c3(15,4);
	Point c4(150,4);
}

namespace cnt3 {
	Point c1(0,5);
	Point c2(14,5);
	Point c3(0,30);
	Point c4(14,30);
}

namespace cnt4 {
	Point c1(15,5);
	Point c2(150,5);
	Point c3(15,30);
	Point c4(150,30);
}