#pragma once
#include<random>
#include"CField.h"

using namespace UserInterface;

class CResursa
{
public:
	void newSun(UserInterface::CField &game);
	void collectSun(UserInterface::CField& game, int place);
};

