#pragma once
#include "CZombie.h"
class CBucketHeadZombie :
	public CZombie
{
public:
	CBucketHeadZombie(int difficulty, UserInterface::CField& game, char type) :CZombie(difficulty, game, type) {;	}
	


	
	
};

