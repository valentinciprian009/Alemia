Cand jocul porneste trebuie sa introduceti nivelul de dificultate de la tastature
Imediat dupa apare interfata grafica a jocului, iar in functie de nivelul de dificultate zombie vor aparea pe
liniile aferente

How to play:
Pentru a planta o planta, trebuie facut dublu click pe planta dorita din coloana din stanga, iar mai apoi dublu click
pe casuta unde vrem sa o plantam.
Pentru a colect resursele de tip sun ce apar pe prima linie trebuie sa facem dublu click pe resursa ce dorim a o colecta


Peashotter-ele trag cu o anumita frecventa gloante care se atunci cand se lovesc de un zombie ia fac un damage
Daca hp-ul unui zombie a ajuns <=0 atunci acesta dispare
Daca plantam sunflower, atunci durata de aparitie a resurselor scade
Scorul apare in partea stanga, odata ce s-a ajuns la 15 jocul este castigat de catre player
Daca un zombie ajunge la casa jocul este pierdut "Game over"

POO:
am folosit stl-uri, singleton-uri
interfete pe care le-am folosit in crearea unor vectori din stl
diamond inheritance pentru clasele plants si zombie